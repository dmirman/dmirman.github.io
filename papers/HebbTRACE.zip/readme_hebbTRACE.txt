Some information for HebbTRACE simulations

Lexicon: dlex2
Parameters: params2

New phonemes:
M - male ambiguous fricative
F - female ambiguous fricative
W - male /s/
X - male /S/
Y - female /s/
Z - female /S/
C - male ambiguous coronal stop
G - female ambiguous coronal stop

new parameters:
lrate - learning rate
atten - lexical attentional gain parameter (1=standard, 0=removed lexicon)
beta - lexical attentional bias parameter (0=standard, 10=removed lexicon)

for categorization testing the lexicon is turned off (atten=0, beta=10) and learning is turned off (lrate=0)
for training/exposure the lexicon is turned on (atten=1, beta=0) and learning is turned on (lrate=0.001).

new functions:
ww - write weights: the feature-to-phoneme weights are written to a file called weights.txt.  If the file exists, the weights are appended to the end.  Useful for checking the effect of tuning on the weights.

reset - reset the weights to their original values.  Useful for running multiple training runs in one script.  This function is not too smart, so if you change the initial phoneme specifications (gfv.c), you will need to update the values in reset.

params_info.txt: labels for the parameters in the params* files

script_sssh_unambig.txt: an example script which tests the standard lexically-guided tuning effect for an ambiguous fricative and the post-test consequences on unambiguous fricatives.  To replicate Simulation 1 use the following command: 

./trace -p params2 -l dlex2 -s script_sssh_unambig.txt

the output will be written to HT_shss_unambig.out and the weights will be written to weights.txt